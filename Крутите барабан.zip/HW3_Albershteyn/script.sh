JAVAFX_LIB="/Users/germanalbershteyn/Desktop/javafx-sdk-22.0.1/lib/"

java --module-path $JAVAFX_LIB:jars/Client.jar -m com.example.hw3_albershteyn/com.example.hw3_albershteyn.GameClient