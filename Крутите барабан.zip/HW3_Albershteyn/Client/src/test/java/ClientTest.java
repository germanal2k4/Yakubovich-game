//import com.example.hw3_albershteyn.Client;
//import org.junit.jupiter.api.*;
//
//import java.util.concurrent.Executors;
//import java.io.DataInputStream;
//import java.io.DataOutputStream;
//import java.io.IOException;
//import java.net.Socket;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.Mockito.*;
//import java.io.*;
//import java.net.*;
//import java.util.concurrent.ExecutorService;
//import java.util.concurrent.ScheduledExecutorService;
//
//class ClientTest {
//    public static class TrainingServer {
//        private final int port;
//        private ServerSocket serverSocket;
//
//        public TrainingServer(int port) {
//            this.port = port;
//        }
//
//        public void start() throws IOException {
//            serverSocket = new ServerSocket(port);
//            serverSocket.setSoTimeout(10000);
//            System.out.println("Server started on port " + port);
//
//            while (true) {
//                try (Socket clientSocket = serverSocket.accept();
//                     DataOutputStream out = new DataOutputStream(clientSocket.getOutputStream());
//                     DataInputStream in = new DataInputStream(clientSocket.getInputStream())) {
//
//                    System.out.println("Client connected");
//
//                    String playerName = in.readUTF();
//                    System.out.println("Received player name: " + playerName);
//
//                    out.writeUTF("ID");
//                    out.writeInt(123);
//                    out.writeInt(5);
//                    out.writeInt(30);
//
//                    out.writeUTF("conditions");
//                    out.writeInt(1);
//                    out.writeUTF(playerName + " *****");
//
//                    out.writeUTF("Game over");
//                    out.writeUTF("You won!");
//
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
//        }
//
//        public synchronized void  stop() throws IOException {
//            if (serverSocket != null && !serverSocket.isClosed()) {
//                serverSocket.close();
//            }
//        }
//
//    }
//    private static TrainingServer trainingServer;
//    private static Thread serverThread;
//    private Client client;
//    private ScheduledExecutorService scheduler;
//
//    @BeforeAll
//    static void setUpServer() throws IOException {
//        trainingServer = new TrainingServer(12345);
//        serverThread = new Thread(() -> {
//            try {
//                trainingServer.start();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        });
//        serverThread.start();
//
//        try {
//            Thread.sleep(1000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//    }
//
//    @AfterAll
//    static void tearDownServer() throws IOException {
//        serverThread.interrupt();
//        trainingServer.stop();
//    }
//
//    @BeforeEach
//    void setUpClient() {
//        client = new Client(12345, "testPlayer", "localhost");
//    }
//
//    @AfterEach
//    void tearDownClient() {
//        scheduler.shutdown();
//    }
//
//
//    @Test
//    void testStopGame() {
//        client.stopGame();
//        assertTrue(client.getStop());
//    }
//
//    @Test
//    void testChangeFlag() {
//        assertFalse(client.getFlag());
//        client.changeFlag();
//        assertTrue(client.getFlag());
//    }
//
//
//}